-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 09, 2024 at 11:52 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `ddea`
--

CREATE TABLE `ddea` (
  `id` int(11) NOT NULL,
  `department` varchar(50) NOT NULL,
  `commentername` varchar(255) NOT NULL,
  `telnumber` varchar(20) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `reply` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `reply_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dea`
--

CREATE TABLE `dea` (
  `id` int(11) NOT NULL,
  `department` varchar(50) NOT NULL,
  `commentername` varchar(255) NOT NULL,
  `telnumber` varchar(20) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `reply` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `reply_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dm`
--

CREATE TABLE `dm` (
  `id` int(11) NOT NULL,
  `department` varchar(50) NOT NULL,
  `commentername` varchar(255) NOT NULL,
  `telnumber` varchar(20) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `reply` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `reply_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `economicdevelopment`
--

CREATE TABLE `economicdevelopment` (
  `id` int(11) NOT NULL,
  `department` varchar(50) NOT NULL,
  `commentername` varchar(255) NOT NULL,
  `telnumber` varchar(20) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `reply` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `reply_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `education`
--

CREATE TABLE `education` (
  `id` int(11) NOT NULL,
  `department` varchar(50) NOT NULL,
  `commentername` varchar(255) NOT NULL,
  `telnumber` varchar(20) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `reply` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `reply_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `goodgovernance`
--

CREATE TABLE `goodgovernance` (
  `id` int(11) NOT NULL,
  `department` varchar(50) NOT NULL,
  `commentername` varchar(255) NOT NULL,
  `telnumber` varchar(20) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `reply` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `reply_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `healthsocialdevelopment`
--

CREATE TABLE `healthsocialdevelopment` (
  `id` int(11) NOT NULL,
  `department` varchar(50) NOT NULL,
  `commentername` varchar(255) NOT NULL,
  `telnumber` varchar(20) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `reply` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `reply_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `healthsocialdevelopment`
--

INSERT INTO `healthsocialdevelopment` (`id`, `department`, `commentername`, `telnumber`, `gender`, `comment`, `reply`, `created_at`, `reply_date`) VALUES
(2, 'Health&SocialDevelopment', 'HAKIM', '07899999', 'male', 'Mwakoze cyane uburyo mwatwakiriye twashimye nukuri kwimana kandi nubutaha muzajye mugira umutima mwiza nokubandi', 'Mwakoze gushima,muzajye muhora mwisanga muuri serivise zakarere', '2024-05-09 11:30:36', '2024-05-09 11:31:50');

-- --------------------------------------------------------

--
-- Table structure for table `ibiza`
--

CREATE TABLE `ibiza` (
  `id` int(11) NOT NULL,
  `department` varchar(50) NOT NULL,
  `commentername` varchar(255) NOT NULL,
  `telnumber` varchar(20) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `reply` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `reply_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `idp`
--

CREATE TABLE `idp` (
  `id` int(11) NOT NULL,
  `department` varchar(50) NOT NULL,
  `commentername` varchar(255) NOT NULL,
  `telnumber` varchar(20) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `reply` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `reply_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `infrastructure`
--

CREATE TABLE `infrastructure` (
  `id` int(11) NOT NULL,
  `department` varchar(50) NOT NULL,
  `commentername` varchar(255) NOT NULL,
  `telnumber` varchar(20) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `reply` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `reply_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inspection`
--

CREATE TABLE `inspection` (
  `id` int(11) NOT NULL,
  `department` varchar(50) NOT NULL,
  `commentername` varchar(255) NOT NULL,
  `telnumber` varchar(20) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `reply` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `reply_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inspectionofwork`
--

CREATE TABLE `inspectionofwork` (
  `id` int(40) NOT NULL,
  `department` varchar(50) NOT NULL,
  `commentername` varchar(76) NOT NULL,
  `telnumber` varchar(10) NOT NULL,
  `gender` varchar(7) NOT NULL,
  `comment` varchar(250) NOT NULL,
  `rely` varchar(200) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `reply_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `it`
--

CREATE TABLE `it` (
  `id` int(11) NOT NULL,
  `department` varchar(50) NOT NULL,
  `commentername` varchar(255) NOT NULL,
  `telnumber` varchar(20) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `reply` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `reply_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `land`
--

CREATE TABLE `land` (
  `id` int(11) NOT NULL,
  `department` varchar(50) NOT NULL,
  `commentername` varchar(255) NOT NULL,
  `telnumber` varchar(20) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `reply` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `reply_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `me`
--

CREATE TABLE `me` (
  `id` int(11) NOT NULL,
  `department` varchar(50) NOT NULL,
  `commentername` varchar(255) NOT NULL,
  `telnumber` varchar(20) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `reply` text DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `reply_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `department` varchar(50) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `department`, `username`, `password`) VALUES
(12, 'Admin', 'admin', '123'),
(13, 'Admin', 'super', '123'),
(20, 'HealthSocialDevelopment', 'Abdoul', '123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ddea`
--
ALTER TABLE `ddea`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department` (`department`);

--
-- Indexes for table `dea`
--
ALTER TABLE `dea`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department` (`department`);

--
-- Indexes for table `dm`
--
ALTER TABLE `dm`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department` (`department`);

--
-- Indexes for table `economicdevelopment`
--
ALTER TABLE `economicdevelopment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department` (`department`);

--
-- Indexes for table `education`
--
ALTER TABLE `education`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department` (`department`);

--
-- Indexes for table `goodgovernance`
--
ALTER TABLE `goodgovernance`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department` (`department`);

--
-- Indexes for table `healthsocialdevelopment`
--
ALTER TABLE `healthsocialdevelopment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ibiza`
--
ALTER TABLE `ibiza`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department` (`department`);

--
-- Indexes for table `idp`
--
ALTER TABLE `idp`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department` (`department`);

--
-- Indexes for table `infrastructure`
--
ALTER TABLE `infrastructure`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department` (`department`);

--
-- Indexes for table `inspection`
--
ALTER TABLE `inspection`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department` (`department`);

--
-- Indexes for table `inspectionofwork`
--
ALTER TABLE `inspectionofwork`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `it`
--
ALTER TABLE `it`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department` (`department`);

--
-- Indexes for table `land`
--
ALTER TABLE `land`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department` (`department`);

--
-- Indexes for table `me`
--
ALTER TABLE `me`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department` (`department`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ddea`
--
ALTER TABLE `ddea`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dea`
--
ALTER TABLE `dea`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dm`
--
ALTER TABLE `dm`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `economicdevelopment`
--
ALTER TABLE `economicdevelopment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `education`
--
ALTER TABLE `education`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `goodgovernance`
--
ALTER TABLE `goodgovernance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `healthsocialdevelopment`
--
ALTER TABLE `healthsocialdevelopment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ibiza`
--
ALTER TABLE `ibiza`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `idp`
--
ALTER TABLE `idp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `infrastructure`
--
ALTER TABLE `infrastructure`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `inspection`
--
ALTER TABLE `inspection`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `inspectionofwork`
--
ALTER TABLE `inspectionofwork`
  MODIFY `id` int(40) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `it`
--
ALTER TABLE `it`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `land`
--
ALTER TABLE `land`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `me`
--
ALTER TABLE `me`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
