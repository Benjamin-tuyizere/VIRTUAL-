<!DOCTYPE html>
<html>
<head>
  <title>Create Account</title>
  <style>
    body {
      font-family: Arial, Helvetica, sans-serif;
      margin: 20px;
    }

    form {
      border: 3px solid #f1f1f1;
      padding: 20px;
      width: 300px;
      margin: 0 auto;
    }

    label {
      display: block;
      margin-bottom: 10px;
    }

    input[type="text"], input[type="password"] {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: inline-block;
      border: 1px solid #ccc;
      box-sizing: border-box;
    }

    button {
      background-color: #04AA6D;
      color: white;
      padding: 14px 20px;
      border: none;
      cursor: pointer;
      width: 100%;
    }

    button:hover {
      opacity: 0.8;
    }

    .error {
      color: red;
      margin-bottom: 10px;
    }
  </style>
</head>
<body>

  <h1>Create Account</h1>

  <form action="signup.php" method="post">
    <label for="department">Serivise:</label><br>
    <select id="department" name="department" required>
        <option value="" disabled selected>Serivice wakiriwemo</option>
        <option value="GoodGovernance">Good Governance</option>
        <option value="HealthSocialDevelopment">Health&Social Dev</option>
        <option value="EconomicDevelopment">EconomicDevelopment</option>
        <option value="DM">DM</option>
        <option value="DEA">DEA</option>
        <option value="DDEA">DDEA</option>
        <option value="Education">Education</option>
        <option value="IT">ICT</option>
        <option value="M&E">M&E</option>
        <option value="IDP">IDP</option>
        <option value="Ibiza">Ibiza</option>
        <option value="Land">Land</option>
        <option value="Infrastructure">Infrastructure</option>
        <option value="Inspection">Inspection</option>
        <option value="Inspection of Work">Inspection of Work</option>
        
    </select><br><br>
    <label for="username">Username:</label>
    <input type="text" id="username" name="username" placeholder="Enter Username" required>
    <br><br>
    <label for="email">Password:</label>
    <input type="text" id="password" name="password" placeholder="Enter Password" required>
    <br><br>
    <button type="submit">Create Account</button>
    <button type="button" onclick="history.back(); return false;">Back</button>
  </form>

</body>
</html>
