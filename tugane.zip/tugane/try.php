<?php
session_start(); // Start the session if not already started

if (!isset($_SESSION['username'])) {
  // User not logged in, redirect to login page
  header("Location: login.php"); // Replace with your login page URL
  exit();
}

$username = $_SESSION['username']; // Retrieve username from session

// Database connection parameters
$servername = "localhost"; // Change this to your database server name
$username = "root"; // Change this to your database username
$password = ""; // Change this to your database password
$dbname = "tugane"; // Change this to your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Get department from GET request (or modify to get it from a form)
$department = $_GET['department']; // Adjust based on how you retrieve department

// Choose table based on department
$tableName = "";
if ($department === "GoodGovernance") {
  $tableName = "comments";
} else if ($department === "Admin") {
  header("Location: Adminpage.php");
} else if ($department === "Health&Social Development") {
  $tableName = "comments2"; // Select from finance_comments for finance
} else if ($department === "Economic Development") {
  $tableName = "comments3"; // Select from marketing_comments
} else if ($department === "DM") {
  $tableName = "comments4"; // Select from marketing_comments
} else if ($department === "DEA") {
  $tableName = "comments5"; // Select from management_feedback
} else if ($department === "DDEA") {
  $tableName = "comments6"; // Select from management_feedback
} else if ($department === "Education") {
  $tableName = "comments7"; // Select from management_feedback
} else if ($department === "IT") {
  $tableName = "comments8"; // Select from management_feedback
} else if ($department === "M&E") {
  $tableName = "comments9"; // Select from management_feedback
} else if ($department === "IDP") {
  $tableName = "comments10"; // Select from management_feedback
} else if ($department === "Ibiza") {
  $tableName = "comments11"; // Select from management_feedback
} else if ($department === "Land") {
  $tableName = "comments12"; // Select from management_feedback
} else if ($department === "Infrastructure") {
  $tableName = "comments13"; // Select from management_feedback
} else if ($department === "Inspection") {
  $tableName = "comments14"; // Select from management_feedback
} else if ($separate === "Inspection of Work") {
  $tableName = "comments15"; // Select from management_feedback
} else {
  echo "Invalid department selected."; // Handle invalid department selection
}

// Retrieve data from database (if a valid table is chosen)
if ($tableName !== "") {
  $sql = "SELECT * FROM " . $tableName; // Select all columns

  $result = $conn->query($sql);

  if ($result->num_rows > 0) {
    echo '<div class="container">'; // Wrap content in a container

    echo '<div class="top-right-info">';  // Top right corner info section
      echo '<span class="username">' . $department . '</span>';
      // ... (profile picture code as before, if applicable)
    echo '</div>';

    echo '<table>';
    echo "<style>"; // Inline style block for table formatting
    echo "
      .container {
        display: flex;
        flex-direction: column;
      }

      .top-right-info {
        display: flex;
        align-items: center;
        justify-content: flex-end;
        margin-bottom: 20px;
      }

      .username {
        margin-right: 10px; /* Adjust spacing as needed */
        font-weight: bold;
      }

      /* ... (rest of your existing table styles) */
    ";
   echo "</style>"; // Close inline style block

echo "<tr>";
echo "<th>Department</th>";
echo "<th>Commenter Name</th>";
echo "<th>Phone Number</th>";
echo "<th>Gender</th>";
echo "<th>Comment</th>";
echo "<th>Reply</th>";
echo "<th>UPDATE</th>";
echo "</tr>";

// Loop through results and display data
while ($row = $result->fetch_assoc()) {
      $commentId = $row["id"]; // Get comment ID for each row
      echo "<tr>";
      echo "<td>" . $row["department"] . "</td>";
      echo "<td>" . $row["commentername"] . "</td>";
      echo "<td>" . $row["telnumber"] . "</td>";
      echo "<td>" . $row["gender"] . "</td>";
      echo "<td>" . $row["comment"] . "</td>";

      echo "<td>";
      // Replace button with textarea for reply
      echo "<textarea rows='4' cols='50' name='reply_$commentId'>{$row['reply']}</textarea>";  echo "</td>";

      // Update button with form and hidden comment ID
      echo "<td><form method='post' action='update.php'>";
      echo "<input type='hidden' name='comment_id' value='$commentId'>";
      echo "<button type='submit' name='update'>UPDATE</button>";
      echo "</form></td>";
      echo "</tr>";
}

echo "</table>";

}

 else {
  echo "No comments found for department: $department.";
 }
} else {
 echo "Please select a valid department.";
}

$conn->close();
?>