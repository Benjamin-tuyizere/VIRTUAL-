<!DOCTYPE html>
<html>
<head>
  <title>Your Page Title</title>
  <link rel="stylesheet" href="stale.css">
</head>
<body>

<?php
// Database connection parameters
$servername = "localhost"; // Change this to your database server name
$username = "root"; // Change this to your database username
$password = ""; // Change this to your database password
$dbname = "tugane"; // Change this to your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
 die("Connection failed: " . $conn->connect_error);
}

// Get department from GET request (or modify to get it from a form)
$department = $_GET['department']; // Adjust based on how you retrieve department

// Choose table based on department
$tableName = "";
if ($department === "GoodGovernance") {
 $tableName = "GoodGovernance"; 
} else if ($department === "Admin") {
 header("Location: Adminpage.php");
} else if ($department === "HealthSocialDevelopment") {
 $tableName = "HealthSocialDevelopment"; // Select from finance_comments for finance
} else if ($department === "EconomicDevelopment") {
  $tableName = "EconomicDevelopment"; // Select from marketing_comments
} else if ($department === "DM") {
 $tableName = "DM"; // Select from marketing_comments
} else if ($department === "DEA") {
 $tableName = "DEA"; // Select from management_feedback
} else if ($department === "DDEA") {
 $tableName = "DDEA"; // Select from management_feedback
}else if ($department === "Education") {
 $tableName = "Education"; // Select from management_feedback
}else if ($department === "IT") {
 $tableName = "IT"; // Select from management_feedback
}else if ($department === "M&E") {
 $tableName = "ME"; // Select from management_feedback
}else if ($department === "IDP") {
 $tableName = "IDP"; // Select from management_feedback
}else if ($department === "Ibiza") {
 $tableName = "Ibiza"; // Select from management_feedback
}else if ($department === "Land") {
 $tableName = "Land"; // Select from management_feedback
}else if ($department === "Infrastructure") {
 $tableName = "Infrastructure"; // Select from management_feedback
}else if ($department === "Inspection") {
 $tableName = "Inspection"; // Select from management_feedback
}else if ($department === "Inspection of Work") {
 $tableName = "InspectionofWork"; // Select from management_feedback
}
else {
 echo "Invalid department selected."; // Handle invalid department selection
}

// Retrieve data from database (if a valid table is chosen)
if ($tableName !== "") {
 $sql = "SELECT * FROM " . $tableName; // Select all columns

 $result = $conn->query($sql);

 if ($result->num_rows > 0) {
  echo "<h3 > $department Department</h3>";
  echo "<table>";
  echo "<style>"; // Inline style block for table formatting
  echo "
   table {
    border-collapse: collapse;
    margin: 20px auto;
    font-size: 16px;
    width: 80%; /* Adjust table width as needed */
   }
   th, td {
    padding: 10px;
    text-align: left;
    border: 1px solid #ddd;
   }
   th {
    background-color: #f2f2f2;
   }
  ";
  echo "</style>"; // Close inline style block

echo "<tr>";
echo "<th>Commenter Name</th>";
echo "<th>Phone Number</th>";
echo "<th>Gender</th>";
echo "<th>Comment</th>";
echo "<th>Date</th>";
echo "<th>Reply</th>";
echo "</tr>";

// Loop through results and display data
while ($row = $result->fetch_assoc()) {
      $id = $row["id"]; // Get comment ID for each row
      echo "<tr>";
      echo "<td>" . $row["commentername"] . "</td>";
      echo "<td>" . $row["telnumber"] . "</td>";
      echo "<td>" . $row["gender"] . "</td>";
      echo "<td>" . $row["comment"] . "</td>";
      echo "<td>" . $row["created_at"] . "</td>";
      // Replace button with textarea for reply
      echo "<td>";
echo "<form action='update_reply.php' method='post'>";
echo "<textarea name='reply' rows='9' cols='30' style='width: 100%; height:35%; resize: vertical;'>" . $row["reply"] . "</textarea>";
echo "<input type='hidden' name='id' value='$id'>";
// Add a hidden input for department
echo "<input type='hidden' name='department' value='$department'>";
echo "<button type='submit' style='padding: 5px 10px; font-size: 14px;'>Update</button>";
echo "</form>";

echo "</td>";

      echo "</tr>";
}

echo "</table>";

}


 else {
  echo "No comments found for department: $department.";
 }
} else {
 echo "Please select a valid department.";
}

$conn->close();
?>

  <style>

    /* Base styles for all buttons */
    button {
      background-color: #34A56F;
      color: white;
      font-size: 18px;
      padding: 10px 113.5px;
      border: none;
      cursor: pointer;
      font-weight: bold;
      font-family: Arial, Helvetica, sans-serif;
      transition: background-color 0.2s ease-in-out; /* Smooth transition on hover */
    }

    /* Styles for the logout button specifically */
    button.logout {
      background-color: lightblue; /* Make logout button red */
    }

    /* Hover effect for all buttons (optional) */
    button:hover {
      background-color: #2980b9; /* Darker shade on hover */
    }
  </style>
</head>
<body>
  

  <?php

  // Check if the user is logged in (replace with your authentication logic)
  if (isLoggedIn()) {
    // Create a logout link with a confirmation prompt
    echo '<button class="logout"><a href="index.php" onclick="return confirm(\'Are you sure you want to log out?\')">Logout</a></button>';
  } else {
    // Display a message if the user is not logged in
    echo 'You are not logged in.';
  }

  // Function to check login status (replace with your implementation)
  function isLoggedIn() {
    // Implement logic to check if a valid user session exists
    return true; // Replace with actual check
  }

  ?>
</body>
</html>
