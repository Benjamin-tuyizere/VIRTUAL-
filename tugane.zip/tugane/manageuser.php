<!DOCTYPE html>
<html>
<head>
  <title>User Management</title>
  <style>
    table {
      border-collapse: collapse;
      width: 100%;
    }
    th, td {
      text-align: left;
      padding: 5px 10px;
      border: 1px solid #ddd;
    }
    button {
      background-color: #4CAF50; /* Green */
      color: white;
      padding: 14px 20px;
      border: none;
      cursor: pointer;
      margin-top: 10px;
    }
  </style>
</head>
<body>

  <h1>User Management</h1>

  <table>
    <tr>
      <th>User ID</th>
      <th>Department</th>
      <th>User Name</th>
      <th>Action</th>
    </tr>
    <?php
      // Connect to your database (Assuming MySQL as an example)
      $conn = mysqli_connect("localhost", "root", "", "tugane");

      // Check connection
      if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
      }

      // Fetch data from the database
      $sql = "SELECT * FROM user";
      $result = mysqli_query($conn, $sql);

      if (mysqli_num_rows($result) > 0) {
        // Output data of each row
        while ($row = mysqli_fetch_assoc($result)) {
          $id = $row['id'];
          $department = $row['department'];
          $username = $row['username'];
          $password = $row['password'];
          echo "<tr>";
          echo "<td>" . $id . "</td>";
          echo "<td>" . $department . "</td>";
          echo "<td>" . $username . "</td>";
          echo '<td>
                  <button class="btn btn-primary"><a href="update1.php?updateid=' . $id . '" class="text-light">Update</a></button>
                  <button onclick="deleteUser(' . $id . ')">Delete</button>
                </td>';
          echo "</tr>";
        }
      } else {
        echo "0 results";
      }

      mysqli_close($conn);
    ?>
  </table>

  <button onclick="addUser()" style="width: 70%;">Add User</button>

  <script>
    // Function to add a new user row (implement your logic here)
     function adminland() {
      // Replace this with your logic to redirect or handle adding a user
      window.location.href = "adminland.php"; // Example redirect to add user page
    }
    function addUser() {
      // Replace this with your logic to redirect or handle adding a user
      window.location.href = "createaccount.php"; // Example redirect to add user page
    }

    // Function to update a user
    function updateUser(userId) {
      // Redirect to update user page with ID
      window.location.href = "update1.php?id=" + userId;
    }

    // Function to delete a user (with confirmation)
    function deleteUser(userId) {
      if (confirm("Are you sure you want to delete this user?")) {
        // Send AJAX request or redirect to delete script with ID
        window.location.href = "delete.php?id=" + userId; // Example redirect
      }
    }
  </script>
  <button onclick="adminland()" style="width: 30%;">Back</button>
</body>
</html>
