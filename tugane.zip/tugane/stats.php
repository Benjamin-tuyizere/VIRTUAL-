<!DOCTYPE html>
<html>
<head>
 <link rel="stylesheet" href="style.css">
  <style>
    /* Target the container element that holds the statistics boxes */
    .container {
        margin: 100px auto; /* Center the container horizontally and add top margin */
        padding: 50px;
        background-color: #f9f9f9;
        border: 1px solid #ddd;
        border-radius: 10px;
        text-align: center; /* Center the content inside the container */
    }

    /* Style for the individual statistics boxes */
    .container div {
        display: inline-block; /* Make boxes appear side-by-side */
        margin: 20px 10px; /* Add more top margin and space between boxes */
        padding: 20px; /* Increase padding for more content space */
        text-align: center; /* Center content within each box */
        width: 600px; /* Increase box width */
        background-color: lightgreen; /* Example color (change as needed) */
        border: 1px solid #ccc;
        border-radius: 10px; /* Rounded corners for better aesthetics */
    }

    /* Optional styles for individual box titles (h3) */
    .container div h3 {
        margin-bottom: 10px; /* Add space between title and content */
    }
</style>

</head>
<br><br>
<h2 style="margin: 0 auto;" align="center">Statistics</h2><br><br><br>
<body>
 <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tugane";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Variables to store counts
$totalComments = 0; // Track total comments
$yearlyComments = []; // Track comments for each year (count)
$weeklyComments = []; // Track comments for each week (year-week format, count)
$monthlyComments = []; // Track comments for each month (year-month format, count)

// Connect to the database (assuming connection details are elsewhere)
// ... (replace with your connection logic)

// Query to retrieve all tables excluding "users"
$sql = "SHOW TABLES";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // Loop through each table
  while ($row = $result->fetch_row()) {
    $tableName = strtoupper($row[0]); // Convert table name to uppercase

    // Exclude "users" table
    if ($tableName != 'USER') {
      // Check if "comment" and "created_at" fields exist
      $fieldCheckSql = "DESCRIBE $tableName";
      $fieldCheckResult = $conn->query($fieldCheckSql);

      if ($fieldCheckResult->num_rows > 0) {
        $hasCommentField = false;
        $hasCreatedAtField = false;
        while ($fieldRow = $fieldCheckResult->fetch_assoc()) {
          if ($fieldRow['Field'] === 'comment') {
            $hasCommentField = true;
          }
          if ($fieldRow['Field'] === 'created_at') {
            $hasCreatedAtField = true;
          }
        }

        if ($hasCommentField && $hasCreatedAtField) {
          // If "comment" and "created_at" fields exist, get comments
          $dataSql = "SELECT comment, created_at FROM $tableName WHERE comment IS NOT NULL";
          $dataResult = $conn->query($dataSql);

          if ($dataResult->num_rows > 0) {
            while ($dataRow = $dataResult->fetch_assoc()) {
              $timestamp = strtotime($dataRow['created_at']);
              $year = date('Y', $timestamp);
              $week = date('Y-W', $timestamp); // Week format (year-week) - Changed to year-week for direct comparison
              $month = date('Y-m', $timestamp); // Month format (year-month)

              $totalComments++;

              // Update yearly, weekly, and monthly counts
              $yearlyComments[$year] = isset($yearlyComments[$year]) ? $yearlyComments[$year] + 1 : 1;
              $weeklyComments[$week] = isset($weeklyComments[$week]) ? $weeklyComments[$week] + 1 : 1;
              $monthlyComments[$month] = isset($monthlyComments[$month]) ? $monthlyComments[$month] + 1 : 1;
            }
          }
        }
      }
    }
  }
}

echo "<div  style='display: flex; justify-content: space-around;'>";

// Box for Total Comments This Week
echo "<div style='background-color: lightgreen; padding: 10px; border: 1px solid #ccc;'>";
echo "<h3>This Week</h3>";
if (array_key_exists(date('Y-W'), $weeklyComments)) { // Use array_key_exists for exact week match
  echo "<p><strong>Comments:</strong> " . $weeklyComments[date('Y-W')] . "</p>";
} else {
  echo "<p>No comments found for this week.</p>";
}
echo "</div>";

// Box for Total Comments This Month
echo "<div style='background-color: lightblue; padding: 10px; border: 1px solid #ccc;'>";
echo "<h3>This Month</h3>";
if (array_key_exists(date('Y-m'), $monthlyComments)) { // Use array_key_exists for exact month match
  echo "<p><strong>Comments:</strong> " . $monthlyComments[date('Y-m')] . "</p>"; // Display monthly comment count
} else {
  echo "<p>No comments found for this month.</p>";
}
echo "</div>";

// Box for Total Comments in the Database
echo "<div style='background-color: lightgrey; padding: 10px; border: 1px solid #ccc;'>";
echo "<h3>All Comments</h3>";
echo "<p><strong>Total Comments:</strong> $totalComments</p>";
echo "</div>";

echo "</div>";

 
// Close connection
$conn->close();
?>


<div style='display: flex; justify-content: space-around;'>
    </div>

  <br><br><br><br><br><br><br><br><br><br><br><br><br><br>
  <button style=" background-color: #34A56F;
    color: white;
    font-size: 18px;
    padding: 10px 113.5px;
    border: none;
    cursor: pointer;
    font-weight: bold;
    font-family: Arial, Helvetica, sans-serif;" onclick="history.back()">Go Back</button>
</body>
</html>
