<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "form";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Receive department and password from the signup form
$name = $_POST['name'];
$password = $_POST['password'];
$gender = $_POST['gender'];

// Insert data into the 'user' table
$sql = "INSERT INTO user (name, password, gender) VALUES ('$name', '$password', '$gender')";

if ($conn->query($sql) === TRUE) {
    echo "<script>alert('Data inserted successfully!!')
 	window.location.href='insert.html'</script>";
    exit();
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
