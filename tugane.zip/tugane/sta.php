<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Comment Statistics</title>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/charts.min.js" integrity="sha512-IjIzPSA7yqn2v8AOCONaVO2x9kNCMU4JCNOxhvpON2C9r1t0p3H3vM8PmWTu [省略] ON a CDN"></script>
</head>
<body>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tugane";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Variables to store comments data
$commentsData = [
  'labels' => [], // Array for labels (years, weeks, months)
  'datasets' => [
    [
      'label' => 'Comment Count', // Label for the dataset
      'data' => [], // Array for comment counts
    ],
  ],
];

// ... rest of the code remains the same ...

// Loop through each table
while ($row = $result->fetch_row()) {
  // ... (table name processing)

  if ($hasCommentField && $hasCreatedAtField) {
    // ... (data retrieval)

    $timestamp = strtotime($dataRow['created_at']);
    $year = date('Y', $timestamp);
    $week = date('Y-W', strtotime('monday this week', $timestamp));
    $month = date('Y-m', $timestamp);

    $totalComments++;

    // Update commentsData based on your chosen visualization type (replace with your choice):
    $commentsData['labels'][] = $year;  // For yearly comments
    // $commentsData['labels'][] = $week;  // For weekly comments
    // $commentsData['labels'][] = $month; // For monthly comments

    $commentsData['datasets'][0]['data'][] = $yearlyComments[$year];  // For yearly comments
    // $commentsData['datasets'][0]['data'][] = $weeklyComments[$week];  // For weekly comments
    // $commentsData['datasets'][0]['data'][] = $monthlyComments[$month]; // For monthly comments
  }
}

// ... rest of the code (displaying comments) ...

// Close connection
$conn->close();

// Encode commentsData to JSON
$jsonData = json_encode($commentsData);
?>

<div class="container">
  <h2>Comment Statistics</h2>
  <canvas id="commentsChart"></canvas>
</div>

<script>
var ctx = document.getElementById('commentsChart').getContext('2d');
var myChart = new Chart(ctx, {
  type: 'bar', // Change to 'line' or 'pie' if desired
  data: <?php echo $jsonData; ?>,
  options: {
    responsive: true,
    scales: {
      xAxes: [{
        stacked: true, // Optional for stacked bar charts
      }],
      yAxes: [{
        ticks: {
          beginAtZero: true
        }
      }]
    }
  }
});
</script>

</body>
</html>