<?php
// Database connection parameters
$servername = "localhost"; // Change this to your database server name
$username = "root"; // Change this to your database username
$password = ""; // Change this to your database password
$dbname = "tugane"; // Change this to your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Get the current date and time
$currentTime = date("Y-m-d H:i:s");

// Get form data
$department = $_POST['department'];
$commentername = $_POST['commentername'];
$telnumber = $_POST['telnumber'];
$gender = $_POST['gender'];
$comment = $_POST['comment'];

// Choose table based on department and additional logic
$tableName = "";
if ($department === "GoodGovernance") {
  $tableName = "GoodGovernance"; // Insert into comments2 if department is sales
} else if ($department === "Health&SocialDevelopment") {
  $tableName = "HealthSocialDevelopment"; // Insert into finance_comments for finance
} else if ($department === "EconomicDevelopment") {
  $tableName = "EconomicDevelopment"; // Insert into marketing_comments
} else if ($department === "DM") {
  $tableName = "DM"; // Insert into finance_comments for finance
} else if ($department === "DEA") {
  $tableName = "DEA"; // Insert into finance_comments for finance
} else if ($department === "DDEA") {
  $tableName = "DDEA"; // Insert into finance_comments for finance
} else if ($department === "Education") {
  $tableName = "Education"; // Insert into finance_comments for finance
} else if ($department === "IT") {
  $tableName = "IT"; // Insert into finance_comments for finance
} else if ($department === "M&E") {
  $tableName = "ME"; // Insert into finance_comments for finance
} else if ($department === "IDP") {
  $tableName = "IDP"; // Insert into finance_comments for finance
} else if ($department === "Ibiza") {
  $tableName = "Ibiza"; // Insert into finance_comments for finance
} else if ($department === "Land") {
  $tableName = "Land"; // Insert into management_feedback
} else if ($department === "Infrastructure") {
  $tableName = "Infrastructure"; // Insert into finance_comments for finance
} else if ($department === "Inspection") {
  $tableName = "Inspection"; // Insert into finance_comments for finance
} else if ($department === "InspectionofWork") {
  $tableName = "InspectionofWork"; // Insert into finance_comments for finance
} else {
  echo "Invalid department selected."; // Handle invalid department selection
}

// Insert data into database (if a valid table is chosen)
if ($tableName !== "") {
  $sql = "INSERT INTO `" . $tableName . "` (`department`, `commentername`, `telnumber`, `gender`, `comment`, `created_at`) VALUES (?, ?, ?, ?, ?, ?)";

  // Prepare the statement (recommended for security)
  $stmt = $conn->prepare($sql);

  // Bind parameters for security (prevents SQL injection)
  $stmt->bind_param("ssssss", $department, $commentername, $telnumber, $gender, $comment, $currentTime);

  // Execute the prepared statement
  $stmt->execute();

  if ($stmt->affected_rows === 1) {
    echo '<script>alert("Igitekerezo cyanyu cyakiriwe neza!"); window.location.href = "index.php";</script>';
  } else {
    echo "Error: An error occurred while inserting data.";
  }

  // Close the prepared statement
  $stmt->close();
}

$conn->close();
?>
