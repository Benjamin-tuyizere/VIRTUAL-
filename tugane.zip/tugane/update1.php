<?php
// Database connection parameters (**Remember to update these with your actual credentials!**)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tugane";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve user data for update (assuming you have a 'user' table with an 'id' column)
$id = $_GET['updateid'];
$sanitized_id = mysqli_real_escape_string($conn, $id); // Sanitize user input to prevent SQL injection

$sql = "SELECT department, username, password FROM user WHERE id = '$sanitized_id'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $department = $row['department'];
    $username = $row['username'];
    $password = $row['password'];
} else {
    echo "Error: User with ID $id not found.";
}

// Handle form submission
if (isset($_POST['submit'])) {
    $department = $_POST['department'];
    $username = $_POST['username'];
    $password = $_POST['password']; // **Note: Not recommended to store plain text passwords!**

    // Prepare update query with placeholders for sanitized values
    $sanitized_username = mysqli_real_escape_string($conn, $username);
    $sanitized_password = mysqli_real_escape_string($conn, $password); // Sanitize password input as well

    $sql = "UPDATE user SET department = '$department', username = '$sanitized_username', password = '$sanitized_password' WHERE id = '$sanitized_id'";

    if ($conn->query($sql) === TRUE) {
      echo "<script>alert('Record updated successfully!')
  window.location.href='manageuser.php'</script>"; // Replace with your user management page URL

    } else {
        echo "Error updating record: " . $conn->error;
    }
}

// Close connection
$conn->close();
?>
<!DOCTYPE html>
<html>
<head>
  <title>Update Account Details</title>
  <style>
    body {
      font-family: Arial, Helvetica, sans-serif;
      margin: 20px;
    }

    form {
      border: 3px solid #f1f1f1;
      padding: 20px;
      width: 300px;
      margin: 0 auto;
    }

    label {
      display: block;
      margin-bottom: 10px;
    }

    input[type="text"], input[type="password"] {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: inline-block;
      border: 1px solid #ccc;
      box-sizing: border-box;
    }

    button {
      background-color: #04AA6D;
      color: white;
      padding: 14px 20px;
      border: none;
      cursor: pointer;
      width: 100%;
    }

    button:hover {
      opacity: 0.8;
    }

    .error {
      color: red;
      margin-bottom: 10px;
    }
  </style>
</head>
<body>

  <h1>Update Account Details</h1>

  <form method="post">
    <label for="department">Departments:</label><br>
    <select id="department" name="department" >
      <option value="" disabled selected>select department</option>
      <option value="GoodGovernance">Good Governance</option>
      <option value="Health&Social Development">Health&Social Dev</option>
      <option value="EconomicDevelopment">EconomicDevelopment</option>
      <option value="DM">DM</option>
      <option value="DEA">DEA</option>
      <option value="DDEA">DDEA</option>
      <option value="Education">Education</option>
      <option value="IT">ICT</option>
      </select><br><br>

    <label for="username">Username:</label>
    <input type="text" id="username" name="username" placeholder="Enter Username" >
    <br><br>

    <label for="password">Password:</label>
    <input type="password" id="password" name="password" placeholder="Enter Password" >
    <br><br>

    <button type="submit" name="submit">Update Account</button>
    <button type="button" onclick="history.back(); return false;">Back</button>
  </form>

</body>
</html>