<?php
// Database connection
$servername = "localhost"; // Change this to your database server
$username = "root"; // Change this to your database username
$password = ""; // Change this to your database password
$dbname = "tugane"; // Change this to your database name

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Receive username and password from the login form
$department = $_POST['department'];
$username = $_POST['username'];
$password = $_POST['password'];

// Sanitize user input (important for security)
$department = mysqli_real_escape_string($conn, $department);
$password = mysqli_real_escape_string($conn, $password);

// Check if the credentials are correct in the 'users' table
$sql = "SELECT * FROM user WHERE department='$department' AND username='$username' AND password='$password'";
$result = $conn->query($sql);

if ($result->num_rows == 1) {
  $row = $result->fetch_assoc();

  // Start a session to store login information
  session_start();
  $_SESSION['department'] = $department; // Store username in session

  // Get user's role from the user table
  $userRole = $row['role']; // Assuming 'role' field represents user's role

  // Define data access condition based on role
  $dataAccessCondition = "";
  if ($userRole === "admin") {
    $dataAccessCondition = ""; // Show all comments for Admin
  } else {
    $dataAccessCondition = "WHERE department='$department'"; // Show comments based on user's department
  }

  // Build the final SQL query
  $displayQuery = "SELECT * FROM comments " . $dataAccessCondition;

  // Redirect to display2.php with the display query, user's role, and department as GET parameters
  header("Location: display2.php?display_query=" . urlencode($displayQuery) . "&role=" . urlencode($userRole) . "&department=" . urlencode($department));
  exit();
} else {
  // Failed login logic
  echo "<script>alert('Sorry, your not allowed to perfom this action.')
  window.location.href='login.html'</script>";
  exit;  // Important to prevent further output after redirection
}

$conn->close();
?>
