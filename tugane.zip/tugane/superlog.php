<?php

$conn=mysqli_connect("localhost","root","","tugane");

$username=$_REQUEST['username'];
$password=$_REQUEST['password'];



$sql="SELECT * FROM user WHERE username='superuser' AND password='$password'";

$res=mysqli_query($conn,$sql);
$log=mysqli_num_rows($res);
 

 if ($log>=1) {
  
  echo "<script>alert('welcome superuser!!')
  window.location.href='superhome.php'</script>";
 }
 else{
  echo "<script>alert('Sorry, your not allowed to perfom this action.')
  window.location.href='home.php'</script>";
 }

?>