<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Update Reply</title>
</head>
<body>
  <?php
    // Database connection parameters (replace with your actual details)
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "tugane";

    $reply = "";  // Initialize $reply variable

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }

    // Check if form is submitted and ID is present in the URL
    if (isset($_POST["update"]) && isset($_GET["id"])) {
      $reply = $_POST["reply"];   // Get the reply from the form
      $id = $_GET["id"];          // Get the ID from the URL

      // Update query using prepared statement (recommended for security)
      $sql = "UPDATE goodgovernance SET reply=? WHERE id=?";
      $stmt = $conn->prepare($sql);
      $stmt->bind_param("si", $reply, $id);

      // Execute update
      if ($stmt->execute()) {
        echo "Record updated successfully!";
      } else {
        echo "Error updating record: " . $stmt->error;
      }

      // Close the prepared statement
      $stmt->close();
    }

    $conn->close();
  ?>

  <h2>Update Reply</h2>  <form method="post" action="">
    <textarea rows="4" cols="50" name="reply" required><?php echo $reply; ?></textarea><br>
    <button type="submit" name="update">UPDATE</button>
  </form>
</body>
</html>
