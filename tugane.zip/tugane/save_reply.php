<?php
// Database connection details (already defined)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tugane";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$commentId = $_POST['commentId']; // Get comment ID from request
$replyText = $_POST['replyText']; // Get reply text from request

// Prepare SQL statement to update reply
$sql = "UPDATE comments SET reply = ? WHERE id = ?";
$stmt = $conn->prepare($sql);

// Bind parameters to prevent SQL injection
$stmt->bind_param("si", $replyText, $commentId);

if ($stmt->execute()) {
  echo json_encode(array("success" => true)); // Send success response
} else {
  echo json_encode(array("success" => false, "error" => $conn->error)); // Send error response
}

$stmt->close();
$conn->close();
?>
