<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="stale.css">
  <style>
    table {
      width: 100%;
      border-collapse: collapse;
    }

    table, th, td {
      border: 1px solid black;
    }

    th, td {
      padding: 8px;
      text-align: left;
    }

    th {
      background-color: #f2f2f2;
    }

    /* New styles for centering department name */
    h2 {
      text-align: center; /* Center the department name */
      margin-bottom: 10px; /* Add some space between department name and table */
    }
  </style>
</head>
<body>
  <?php
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "tugane";

  // Create connection
  $conn = new mysqli($servername, $username,$password, $dbname);

  // Check connection
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

  // Query to retrieve all tables excluding "users"
  $sql = "SHOW TABLES";
  $result = $conn->query($sql);

  if ($result->num_rows > 0) {
    $has_data_overall = false; // Flag to track if any department has data

    // Loop through each table
    while ($row = $result->fetch_row()) {
      $table_name = strtoupper($row[0]); // Convert table name to uppercase

      // Exclude "users" table
      if ($table_name != 'USER') {
        $has_data = false; // Flag for current department

        // Check if there's data before displaying anything
        $data_sql = "SELECT * FROM $table_name";
        $data_result = $conn->query($data_sql);

        if ($data_result->num_rows > 0) {
          $has_data = true;
          $has_data_overall = true; // Set overall flag if any department has data
        }

        // Only display department name and table if data exists
        if ($has_data) {
    echo "<h2>DEPARTMENT OF $table_name</h2>";
    echo "<table>";

    $header_printed = false;
    while($data_row = $data_result->fetch_assoc()) {
        if (!$header_printed) {
            echo "<tr>";
            foreach($data_row as $key => $value) {
                // Exclude id and department fields from being displayed
                if ($key !== 'id' && $key !== 'department') {
                    echo "<th>$key</th>";
                }
            }
            echo "</tr>";
            $header_printed = true;
        }
        echo "<tr>";
        foreach($data_row as $key => $value) {
            // Exclude id and department values from being displayed
            if ($key !== 'id' && $key !== 'department') {
                echo "<td>$value</td>";
            }
        }
        echo "</tr>";
    }

    echo "</table>";
}
      }
    }

    // Display a message if no departments have data
    if (!$has_data_overall) {
      echo "<p>No data found in any department.</p>";
    }
  } else {
    echo "0 results";
  }

  // Close connection
  $conn->close();
  ?>
  <button style=" background-color: #34A56F;
    color: white;
    font-size: 18px;
    padding: 10px 113.5px;
    border: none;
    cursor: pointer;
    font-weight: bold;
    font-family: Arial, Helvetica, sans-serif;" onclick="history.back()">Go Back</button>
  <button 
    style=" background-color: #34A56F;
    color: white;
    font-size: 18px;
    padding: 10px 113.5px;
    border: none;
    cursor: pointer;
    font-weight: bold;
    font-family: Arial, Helvetica, sans-serif;"onclick="window.print()">Print</button>
</body>
</html>
