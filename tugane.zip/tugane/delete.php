<!DOCTYPE html>
<html>
<head>
  <title>Delete User</title>
</head>
<body>

<?php
  // Database connection parameters
$servername = "localhost"; // Change this to your database server name
$username = "root"; // Change this to your database username
$password = ""; // Change this to your database password
$dbname = "tugane"; // Change this to your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

  // Initialize variables
  $user_id = "";

  // Get user ID from URL parameter (assuming you redirect with user ID)
  if (isset($_GET['id'])) {
    $user_id = $_GET['id'];

    // Prepare SQL statement for deletion (use prepared statements)
    $sql = "DELETE FROM user WHERE id = ?";
    $stmt = $conn->prepare($sql);

    $stmt->bind_param("i", $user_id);

    // Execute the delete query
    if ($stmt->execute()) {
      echo "User deleted successfully!";
    } else {
      echo "Error: " . $stmt->error;
    }

    $stmt->close();
  } else {
    echo "Error: User ID not provided.";
  }

  $conn->close();
?>

<script>
  // Redirect after a brief delay (optional)
  window.setTimeout(function() {
    window.location.href = 'manageuser.php'; // Replace with your user management page URL
  }, 1000); // Redirect after 2 seconds (customize delay if needed)
</script>

</body>
</html>
