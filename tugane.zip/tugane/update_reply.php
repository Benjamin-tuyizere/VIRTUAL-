<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tugane";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get comment ID, reply text, and current date/time
$department = $_POST['department'];
$id = $_POST['id'];
$reply = $_POST['reply'];
$replyDate = date('Y-m-d H:i:s'); // Get current date and time in MySQL format

// Escape data to prevent SQL injection (important for security)
$id = mysqli_real_escape_string($conn, $id);
$reply = mysqli_real_escape_string($conn, $reply);
$replyDate = mysqli_real_escape_string($conn, $replyDate); // Escape date/time as well

// Update reply and reply date in the database
$sql = "UPDATE " . $department . " SET reply='$reply', reply_date='$replyDate' WHERE id='$id'"; // Adjust table name based on department, add reply_date column

if ($conn->query($sql) === TRUE) {
    echo "Reply updated successfully!";
} else {
    echo "Error updating reply: " . $conn->error;
}

// Close connection
$conn->close();

// Redirect back to the display page
header("Location: display2.php?department=" . $_POST['department']);
?>
