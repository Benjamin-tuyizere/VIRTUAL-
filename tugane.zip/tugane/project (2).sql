-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 15, 2024 at 09:48 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `department` varchar(50) NOT NULL,
  `commentername` varchar(255) NOT NULL,
  `telnumber` varchar(20) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `reply` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `department`, `commentername`, `telnumber`, `gender`, `comment`, `reply`) VALUES
(1, 'GoodGovernance', 'HAKIM', '078902983', 'male', 'yes thank you', NULL),
(2, 'GoodGovernance', 'lee', '09876556789', 'male', 'ertyjhbvcdsdfg', NULL),
(3, 'GoodGovernance', 'kim', '07899999', 'female', 'qwertyukjnbvcx', NULL),
(4, 'GoodGovernance', 'Afisa', 'wertyu', 'male', 'mnbvcxzasdfgjkiuytr', NULL),
(5, 'GoodGovernance', 'hakim', '123456', 'male', '234567jhgfdsxcv', NULL),
(6, 'GoodGovernance', '1234', '12345', 'male', 'sdfghj', NULL),
(7, 'GoodGovernance', 'qwer', '65432', 'male', 'asdfghtrfd', NULL),
(8, 'GoodGovernance', 'bbby', '9986', 'female', 'szxtfhbbbb', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `comments2`
--

CREATE TABLE `comments2` (
  `id` int(11) NOT NULL,
  `department` varchar(50) NOT NULL,
  `commentername` varchar(255) NOT NULL,
  `telnumber` varchar(20) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `reply` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comments2`
--

INSERT INTO `comments2` (`id`, `department`, `commentername`, `telnumber`, `gender`, `comment`, `reply`) VALUES
(1, 'Health&Social Development', 'HAKIM', '07899999', 'male', 'qretytghfcnvdgrt', NULL),
(2, 'Health&Social Development', 'lee', '0987654345', 'male', 'ytresdfg', NULL),
(3, 'Health&Social Development', '23456', '234567', 'male', 'wertyhgfc', NULL),
(4, 'Health&Social Development', 'werty', '876543', 'male', 'qwergvdsdgh', NULL),
(5, 'Health&Social Development', 'lwa', '9876', 'female', 'wedszxcv', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `comments3`
--

CREATE TABLE `comments3` (
  `id` int(11) NOT NULL,
  `department` varchar(50) NOT NULL,
  `commentername` varchar(255) NOT NULL,
  `telnumber` varchar(20) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `reply` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comments3`
--

INSERT INTO `comments3` (`id`, `department`, `commentername`, `telnumber`, `gender`, `comment`, `reply`) VALUES
(1, 'EconomicDevelopment', 'iuytre', '23456', 'female', 'iuytrewsdf', NULL),
(2, 'EconomicDevelopment', 'dfcsawg', 'werds', 'female', 'asdfgtgrfd', NULL),
(3, 'EconomicDevelopment', 'bonnefete', '078938474', 'male', 'sinabikunze', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `comments4`
--

CREATE TABLE `comments4` (
  `id` int(11) NOT NULL,
  `department` varchar(50) NOT NULL,
  `commentername` varchar(255) NOT NULL,
  `telnumber` varchar(20) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `reply` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comments4`
--

INSERT INTO `comments4` (`id`, `department`, `commentername`, `telnumber`, `gender`, `comment`, `reply`) VALUES
(1, 'DM', 'lee', '123', 'female', 'iuytrewsdfg', NULL),
(2, 'DM', '23456', 'iuytrewasd', 'female', 'oiuytrewasxcvbn', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `comments5`
--

CREATE TABLE `comments5` (
  `id` int(11) NOT NULL,
  `department` varchar(50) NOT NULL,
  `commentername` varchar(255) NOT NULL,
  `telnumber` varchar(20) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `reply` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comments5`
--

INSERT INTO `comments5` (`id`, `department`, `commentername`, `telnumber`, `gender`, `comment`, `reply`) VALUES
(1, 'DEA', 'gwanzu', '98765', 'female', 'gfjgafuyre', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `comments6`
--

CREATE TABLE `comments6` (
  `id` int(11) NOT NULL,
  `department` varchar(50) NOT NULL,
  `commentername` varchar(255) NOT NULL,
  `telnumber` varchar(20) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `reply` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `comments7`
--

CREATE TABLE `comments7` (
  `id` int(11) NOT NULL,
  `department` varchar(50) NOT NULL,
  `commentername` varchar(255) NOT NULL,
  `telnumber` varchar(20) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `reply` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comments7`
--

INSERT INTO `comments7` (`id`, `department`, `commentername`, `telnumber`, `gender`, `comment`, `reply`) VALUES
(1, 'Education', 'Afisa', '09876', 'female', 'ertyjkmnb cx', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `comments8`
--

CREATE TABLE `comments8` (
  `id` int(11) NOT NULL,
  `department` varchar(50) NOT NULL,
  `commentername` varchar(255) NOT NULL,
  `telnumber` varchar(20) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `reply` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comments8`
--

INSERT INTO `comments8` (`id`, `department`, `commentername`, `telnumber`, `gender`, `comment`, `reply`) VALUES
(1, 'ICT', 'Abdoul', '07809644', 'male', 'Well done', NULL),
(2, 'IT', 'ytrsdvb', '09876543', 'male', 'wertyuikmnbvcx ', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `comments9`
--

CREATE TABLE `comments9` (
  `id` int(11) NOT NULL,
  `department` varchar(50) NOT NULL,
  `commentername` varchar(255) NOT NULL,
  `telnumber` varchar(20) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `reply` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comments9`
--

INSERT INTO `comments9` (`id`, `department`, `commentername`, `telnumber`, `gender`, `comment`, `reply`) VALUES
(1, 'M&E', 'asa', '98765', 'male', 'ertyu', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `comments10`
--

CREATE TABLE `comments10` (
  `id` int(11) NOT NULL,
  `department` varchar(50) NOT NULL,
  `commentername` varchar(255) NOT NULL,
  `telnumber` varchar(20) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `reply` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comments10`
--

INSERT INTO `comments10` (`id`, `department`, `commentername`, `telnumber`, `gender`, `comment`, `reply`) VALUES
(1, 'IDP', '0987654', '0987654', 'male', 'asdfklkuytrf', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `comments11`
--

CREATE TABLE `comments11` (
  `id` int(11) NOT NULL,
  `department` varchar(50) NOT NULL,
  `commentername` varchar(255) NOT NULL,
  `telnumber` varchar(20) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `reply` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `comments12`
--

CREATE TABLE `comments12` (
  `id` int(11) NOT NULL,
  `department` varchar(50) NOT NULL,
  `commentername` varchar(255) NOT NULL,
  `telnumber` varchar(20) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `reply` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comments12`
--

INSERT INTO `comments12` (`id`, `department`, `commentername`, `telnumber`, `gender`, `comment`, `reply`) VALUES
(1, 'Land', 'qwertyuyt', '1234', 'female', 'dffgtr', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `comments13`
--

CREATE TABLE `comments13` (
  `id` int(11) NOT NULL,
  `department` varchar(50) NOT NULL,
  `commentername` varchar(255) NOT NULL,
  `telnumber` varchar(20) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `reply` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `comments14`
--

CREATE TABLE `comments14` (
  `id` int(11) NOT NULL,
  `department` varchar(50) NOT NULL,
  `commentername` varchar(255) NOT NULL,
  `telnumber` varchar(20) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `reply` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `department` varchar(50) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`department`, `username`, `password`) VALUES
('Admin', 'admin', '123'),
('DEA', 'dea', '123'),
('DM', 'dm', '123'),
('EconomicDevelopment', 'eco', '123'),
('Education', 'edu', '123'),
('GoodGovernance', 'good', '123'),
('Health&Social Development', 'social', '123'),
('Ibiza', 'ibiza', '123'),
('ICT', 'IT', '123'),
('IDP', 'IDP', '123'),
('Infrastructure', 'infra', '123'),
('Inspection', 'inspe', '123'),
('Inspection of Work', 'iw', '123'),
('IT', 'IT', '123'),
('Land', 'land', '123'),
('M&E', 'me', '123'),
('Superuser', 'superuser', '123'),
('Inspection of Work', 'rubwa', '123'),
('Land', 'Afisa', '123'),
('Ibiza', 'umugabo', '123'),
('Inspection of Work', 'rutwe', '123'),
('DEA', 'good', '123'),
('IT', 'Yasiri', '123'),
('DEA', 'yay', '123'),
('Inspection', 'Habiba', '123'),
('Infrastructure', 'sales', '123'),
('GoodGovernance', 'Eric', '123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department` (`department`);

--
-- Indexes for table `comments2`
--
ALTER TABLE `comments2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments3`
--
ALTER TABLE `comments3`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department` (`department`);

--
-- Indexes for table `comments4`
--
ALTER TABLE `comments4`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department` (`department`);

--
-- Indexes for table `comments5`
--
ALTER TABLE `comments5`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department` (`department`);

--
-- Indexes for table `comments6`
--
ALTER TABLE `comments6`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department` (`department`);

--
-- Indexes for table `comments7`
--
ALTER TABLE `comments7`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department` (`department`);

--
-- Indexes for table `comments8`
--
ALTER TABLE `comments8`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department` (`department`);

--
-- Indexes for table `comments9`
--
ALTER TABLE `comments9`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department` (`department`);

--
-- Indexes for table `comments10`
--
ALTER TABLE `comments10`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department` (`department`);

--
-- Indexes for table `comments11`
--
ALTER TABLE `comments11`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department` (`department`);

--
-- Indexes for table `comments12`
--
ALTER TABLE `comments12`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department` (`department`);

--
-- Indexes for table `comments13`
--
ALTER TABLE `comments13`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department` (`department`);

--
-- Indexes for table `comments14`
--
ALTER TABLE `comments14`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department` (`department`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `comments2`
--
ALTER TABLE `comments2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `comments3`
--
ALTER TABLE `comments3`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `comments4`
--
ALTER TABLE `comments4`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `comments5`
--
ALTER TABLE `comments5`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `comments6`
--
ALTER TABLE `comments6`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `comments7`
--
ALTER TABLE `comments7`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `comments8`
--
ALTER TABLE `comments8`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `comments9`
--
ALTER TABLE `comments9`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `comments10`
--
ALTER TABLE `comments10`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `comments11`
--
ALTER TABLE `comments11`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `comments12`
--
ALTER TABLE `comments12`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `comments13`
--
ALTER TABLE `comments13`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `comments14`
--
ALTER TABLE `comments14`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
