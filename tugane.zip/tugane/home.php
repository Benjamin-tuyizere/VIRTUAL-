<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style type="text/css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {margin:0}

.icon-bar {
  width: 20%;
  background-color: #555;
}

.icon-bar a {
  display: block;
  text-align: center;
  padding: 16px;
  transition: all 0.3s ease;
  color: white;
  font-size: 36px;
  height: 60%;

}

.icon-bar a:hover {
  background-color: #000;
}
a{
	text-decoration: none;
}
.active {
  background-color: #04AA6D;
body {font-family: Arial, Helvetica, sans-serif;}
form {border: 3px solid #f1f1f1;}

.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: red;
}

.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
}

img.avatar {
  width: 40%;
  border-radius: 50%;
}
a{
	width: 60%;
}


</style>
</head>
<body>
	<h1><center>REPUBULIKA Y'U RWANDA</center></h1>
	<H2><center>AKARERE KA KICUKIRO</center></H2>
	
		 <div class="imgcontainer">
    <center><img src="download.jpg" alt="Avatar" class="avatar"></center>

<div class="icon-bar">
  <a class="active" href="index.php"><i class="fa fa-home"></i></a>
  <a href="login.html"> user </a>
  <a href="superuser.php">super user</a>
  <a href="adlog.php">Admin</a>
  <button style=" background-color: #34A56F;
        color: white;
        font-size: 18px;
        padding: 10px 113.5px;
        border: none;
        cursor: pointer;
        font-weight: bold;
        font-family: Arial, Helvetica, sans-serif; 
        " onclick="history.back()">Back</button>
</div>

</body>
</html>

