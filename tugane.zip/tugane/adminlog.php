<?php
// Database connection
$servername = "localhost"; // Change this to your database server
$username = "root"; // Change this to your database username
$password = ""; // Change this to your database password
$dbname = "tugane"; // Change this to your database name

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Receive username and password from the login form
$username = $_POST['username'];
$password = $_POST['password'];

// Sanitize user input (important for security)
$username = mysqli_real_escape_string($conn, $username);
$password = mysqli_real_escape_string($conn, $password);

// Check if the credentials are correct in the 'users' table
$sql = "SELECT * FROM user WHERE username='$username' AND password='$password'";
$result = $conn->query($sql);

if ($result->num_rows == 1) {
  $row = $result->fetch_assoc();

  // Start a session to store login information
  session_start();
  $_SESSION['username'] = $username; // Store username in session

  // Get user's role from the user table
  $userRole = $row['username']; // Assuming 'role' field represents user's role

  // Define data access condition based on role
  $dataAccessCondition = "";
  if ($userRole === "Admin") {
    $dataAccessCondition = ""; // Show all comments for Admin
  } else {
    $dataAccessCondition = "WHERE username='$username'"; // Show comments based on user's department
  }

  // Build the final SQL query
  $displayQuery = "SELECT * FROM comments " . $dataAccessCondition;

  // Redirect to display2.php with the display query, user's role, and department as GET parameters
  header("Location: Adminpage.php?display_query=" . urlencode($displayQuery) . "&role=" . urlencode($userRole) . "&username=" . urlencode($user));
  exit();
} else {
  echo "Invalid username or password. Please try again.";
}

$conn->close();
?>
