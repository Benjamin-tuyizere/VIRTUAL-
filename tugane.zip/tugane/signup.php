<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tugane";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Receive department and password from the signup form
$department = $_POST['department'];
$username = $_POST['username'];
$password = $_POST['password'];

// Insert data into the 'user' table
$sql = "INSERT INTO user (department, username, password) VALUES ('$department', '$username', '$password')";

if ($conn->query($sql) === TRUE) {
    echo "<script>alert('Account created successfully!!')
 	window.location.href='manageuser.php'</script>";
    exit();
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
