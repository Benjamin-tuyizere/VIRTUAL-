<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style type="text/css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {margin:0;
    margin-top: 100px;
    background-color: #222;}

.icon-bar {
  width: 20%;
  background-color: #555;
}

.icon-bar a {
  display: block;
  text-align: center;
  padding: 16px;
  transition: all 0.3s ease;
  color: white;
  font-size: 36px;
  height: 60%;

}

.icon-bar a:hover {
  background-color: #000;
}
a{
	text-decoration: none;
}
.active {
  background-color: #04AA6D;
body {font-family: Arial, Helvetica, sans-serif;}
form {border: 3px solid #f1f1f1;}

.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: red;
}

.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
}

img.avatar {
  width: 40%;
  border-radius: 50%;
}
a{
	width: 60%;
}


</style>
</head>
<body>
	<h1><center>REPUBULIKA Y'U RWANDA</center></h1>
	<H2><center>AKARERE KA KICUKIRO </center></H2>
	
		 <div class="imgcontainer">
    <center><img src="download.jpg" alt="Avatar" class="avatar"></center>

<div class="icon-bar">
  <a class="active" href="index.php"><i class="fa fa-home"></i></a>
  <a href="manageuser.php">Manage Account</a>
  <a href="Adminpage.php">Report</a>
  <a href="users.php">Users</a>
 
        <?php

// Check if the user is logged in (replace with your authentication logic)
if (isLoggedIn()) {
  // Create a logout link with a confirmation prompt
  echo '<a href="index.php" onclick="return confirm(\'Are you sure you want to log out?\')">Logout</a>';
} else {
  // Display a message if the user is not logged in
  echo 'You are not logged in.';
}

// Function to check login status (replace with your implementation)
function isLoggedIn() {
  // Implement logic to check if a valid user session exists
  return true; // Replace with actual check
}

?>
</div>

</body>
</html>

