<html>
<head>
  </head>
  <body>

<?php

// Database connection details (replace with your actual credentials)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tugane";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// SQL query to select department and username
$sql = "SELECT department, username FROM user";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
  echo "<style>";
  echo "
  table {
    width: 100%;
    border-collapse: collapse;
  }
  
  th, td {
    padding: 10px;
    border: 1px solid #ddd;
    text-align: left;
  }
  
  th {
    background-color: #f2f2f2;
  }
  ";
  echo "</style>";

  echo "<table>";
    echo "<tr>";
      echo "<th>Department</th>";
      echo "<th>Username</th>";
    echo "</tr>";
  
  // Loop through each row and display data
  while($row = $result->fetch_assoc()) {
    echo "<tr>";
      echo "<td>" . $row["department"] . "</td>";
      echo "<td>" . $row["username"] . "</td>";
    echo "</tr>";
  }
  
  echo "</table>";
  // Add the back button form
  echo "<form action='' method='post'>";  // Replace with your actual back page UR
  echo "</form>";
} else {
  echo "No data found in the user table.";
}

$conn->close();
?>
<button style=" background-color: #34A56F;
        color: white;
        font-size: 18px;
        padding: 10px 113.5px;
        border: none;
        cursor: pointer;
        font-weight: bold;
        font-family: Arial, Helvetica, sans-serif;" onclick="history.back()">Go Back</button>
        <button 
         style=" background-color: #34A56F;
        color: white;
        font-size: 18px;
        padding: 10px 113.5px;
        border: none;
        cursor: pointer;
        font-weight: bold;
        font-family: Arial, Helvetica, sans-serif;"onclick="window.print()">Print</button>
</body>
</html>
