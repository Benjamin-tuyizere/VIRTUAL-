 <title>Home page</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <style type="text/css">
  	
  	a{
  		padding: 3rem;
  		text-decoration: none;

  		font-family: bold;
      font-size: 2em;
  	}
  	.home{
  		background-color: whitesmoke;
  	}
  	image{
  		height: 150%;

  	}
  	}
    .footer
{
padding: 20px;
margin-top: 39rem;
background-color: blue;
}
body{
  background-image: url('full.CR2');
  background-size: cover;
  background-position: center;
} 
.top-text{
  font-size: 5rem;
  color: white;
  font-weight: bold;
}

  </style>
</head>
<body>
<div class="home">
	<nav class="navbar navbar-expand-sm bg-gray navbar-gray">

    <img src="https://www.kicukiro.gov.rw/index.php?eID=dumpFile&amp;t=f&amp;f=631&amp;token=aa5d43591eeacf168a3adb6e888a05845b64dd81" alt="Image" height="150">
    <h1>Akarere ka kicukiro</h1>
    <b><a href="#">Ahabanza</a></b>
    <b><a href="home.php">Serivise</a></b>
    <b><a href="form.html">Igitekerezo</a></b>
    <b><a href="stats.php">Imbonerahamwe</a></b>

     <form class="d-flex">
        <input class="form-control me-2" type="text" placeholder="Search">
        <button class="btn btn-primary" type="button">Search</button>
      </form>
    
  </div>
</nav>


<div class="Image">
	<MARQUEE ><div class="top-text"> AGASANDUKU K'IBITEKEREZO</div></MARQUEE>
</div>

</body>
</html>